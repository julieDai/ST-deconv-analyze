import pandas as pd

# 读取 tsv 文件
file_path = "/home/daishurui/git_project/ST-deconv/data/DLPHC/trainset/spatial_count_transposed.tsv"
df = pd.read_csv(file_path, sep='\t', index_col=0)  # 读取TSV文件并将第一列作为索引

# 进行转置
df_transposed = df.T  # 转置矩阵

# 保存转置后的矩阵
output_path = "/home/daishurui/git_project/ST-deconv/data/DLPHC/trainset/spatial_count.tsv"
df_transposed.to_csv(output_path, sep='\t')

print(f"转置后的文件已保存至: {output_path}")